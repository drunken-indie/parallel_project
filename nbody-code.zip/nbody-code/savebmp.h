#ifndef savebmp_h
#define savebmp_h

void saveBMP      (const char* filename, const unsigned char* image, int width, int height);

#endif